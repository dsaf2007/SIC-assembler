#pragma once
#include "HexDec.h"



void pass1();

int search_symtab_pass1(SYMTAB, string, int);

int search_optab_pass1(string);