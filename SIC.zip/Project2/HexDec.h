#pragma once
#include "TABLE.h"



int hexToDec(string);

string decToHex(string);