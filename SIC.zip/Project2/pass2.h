#pragma once

#include "HexDec.h"


void pass2();

int search_symtab_pass2(SYMTAB, string, int);

string search_optab_pass2(string);
