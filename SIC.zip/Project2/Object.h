#pragma once

#include "TABLE.h"

string convertToObject(string, string, int*);



int stringToInt(string);


string object(string, int);

